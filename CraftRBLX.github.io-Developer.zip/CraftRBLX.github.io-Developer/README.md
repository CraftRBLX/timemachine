# https://techmcgamez.github.io/homepage.html
This website was went to advertise/showcase my channel.
